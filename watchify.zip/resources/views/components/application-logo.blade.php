<a href="/">
    <img style="max-width: 150px;" src="{{ config('app.url', '') }}img/logo.png" alt="Home" />
</a>
