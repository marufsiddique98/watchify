<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="px-5">
        <div class="row">
            <div class="col-12 col-md-8">
                <?php echo e($slot); ?>


            </div>
            <div class="col-12 col-md-4">
                <ul class="account-menu">
                    <li>
                        <a href="/profile">My Profile</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('channel.all')); ?>">My Channels</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('video.all')); ?>">My Contents</a>
                    </li>
                    <li>
                        <a method="delete" href="/logout">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH E:\Project\watchify\resources\views/components/account-layout.blade.php ENDPATH**/ ?>