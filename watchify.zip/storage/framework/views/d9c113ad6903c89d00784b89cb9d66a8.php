<a href="/">
    <img style="max-width: 150px;" src="<?php echo e(config('app.url', '')); ?>img/logo.png" alt="Home" />
</a>
<?php /**PATH E:\Project\watchify\resources\views/components/application-logo.blade.php ENDPATH**/ ?>