<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.home-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="sidebar__categories">
        <h3>Featured Channels</h3>
        <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="sidebar__category">
              
              <a href="<?php echo e(route('channel',$c->slug)); ?>"><span><?php echo e($c->name); ?></span></a>

          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <hr />
  </div>
  <!-- Sidebar Ends -->

  <!-- Videos Section -->
  <div class="videos">
    
    <div class="videos__container">

        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="video">
            <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                <div style="border-radius:10px;" class="video__thumbnail">
                    <img style="border-radius:10px;" src="<?php echo e(config('app.url').$video->vthumb); ?>" alt="Video thumbnail" />
                </div>
            </a>
            <div class="video__details">
                <div class="author">
                    <img src="" alt="" />
                </div>
                <div class="title">
                    <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                        <h3>
                            <?php echo e($video->vtitle); ?>

                        </h3>
                    </a>
                    <a href="<?php echo e(route('channel',$video->cslug)); ?>"><?php echo e($video->channel_name); ?></a>
                    <span><?php echo e($video->views); ?> Views •  Ago</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="video">
            <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                <div style="border-radius:10px;" class="video__thumbnail">
                    <img style="border-radius:10px;" src="<?php echo e(config('app.url').$video->vthumb); ?>" alt="Video thumbnail" />
                </div>
            </a>
            <div class="video__details">
                <div class="author">
                    <img src="" alt="" />
                </div>
                <div class="title">
                    <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                        <h3>
                            <?php echo e($video->vtitle); ?>

                        </h3>
                    </a>
                    <a href="<?php echo e(route('channel',$video->cslug)); ?>"><?php echo e($video->channel_name); ?></a>
                    <span><?php echo e($video->views); ?> Views •  Ago</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="video">
            <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                <div style="border-radius:10px;" class="video__thumbnail">
                    <img style="border-radius:10px;" src="<?php echo e(config('app.url').$video->vthumb); ?>" alt="Video thumbnail" />
                </div>
            </a>
            <div class="video__details">
                <div class="author">
                    <img src="" alt="" />
                </div>
                <div class="title">
                    <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                        <h3>
                            <?php echo e($video->vtitle); ?>

                        </h3>
                    </a>
                    <a href="<?php echo e(route('channel',$video->cslug)); ?>"><?php echo e($video->channel_name); ?></a>
                    <span><?php echo e($video->views); ?> Views •  Ago</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="video">
            <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                <div style="border-radius:10px;" class="video__thumbnail">
                    <img style="border-radius:10px;" src="<?php echo e(config('app.url').$video->vthumb); ?>" alt="Video thumbnail" />
                </div>
            </a>
            <div class="video__details">
                <div class="author">
                    <img src="" alt="" />
                </div>
                <div class="title">
                    <a href="<?php echo e(route('video.watch',$video->vslug)); ?>">
                        <h3>
                            <?php echo e($video->vtitle); ?>

                        </h3>
                    </a>
                    <a href="<?php echo e(route('channel',$video->cslug)); ?>"><?php echo e($video->channel_name); ?></a>
                    <span><?php echo e($video->views); ?> Views •  Ago</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH E:\Project\watchify\resources\views/home.blade.php ENDPATH**/ ?>