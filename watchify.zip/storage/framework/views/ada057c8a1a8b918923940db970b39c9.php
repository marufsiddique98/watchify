<div class="video">
    <a href="<?php echo e($link); ?>">
        <div style="border-radius:10px;" class="video__thumbnail">
            <img style="border-radius:10px;" src="<?php echo e($thumbnail); ?>" alt="" />
        </div>
    </a>
    <div class="video__details">
        <div class="author">
            <img src="<?php echo e($channelThumbnail); ?>" alt="" />
        </div>
        <div class="title">
            <a href="<?php echo e($link); ?>">
                <h3>
                    <?php echo e($title); ?>

                </h3>
            </a>
            <a href="<?php echo e($channelLink); ?>"><?php echo e($channelName); ?></a>
            <span><?php echo e($views); ?> Views • <?php echo e($time); ?> Ago</span>
        </div>
    </div>
</div>
<?php /**PATH E:\Project\watchify\resources\views/components/video.blade.php ENDPATH**/ ?>