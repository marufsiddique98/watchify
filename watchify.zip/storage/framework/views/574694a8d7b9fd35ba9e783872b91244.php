<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mainBody">
        <!-- Sidebar Starts -->
        <div class="sidebar">
          <div class="sidebar__categories">
            <div class="sidebar__category">
              <i class="material-icons">home</i>
              <a href="/"><span>Home</span></a>
            </div>
            <div class="sidebar__category">
              <i class="material-icons">local_fire_department</i>
              <a href="/"><span>Trending</span></a>
            </div>
            
            
            <div class="sidebar__category">
              <i class="material-icons">play_arrow</i>
              <a href="<?php echo e(route('video.all')); ?>"><span>Your Videos</span></a>
            </div>
            
          </div>
          <hr />


          <?php echo e($slot); ?>

        </div>
      </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH E:\Project\watchify\resources\views/components/home-layout.blade.php ENDPATH**/ ?>